a = int(input())
b = int(input())

print(a,'+',b,'=',a+b,sep='')
print(f"{a}+{b}={a+b}")

s = f"{a}+{b}={a+b}"
print(s)

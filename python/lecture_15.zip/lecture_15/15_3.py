a = int(input("請輸入長: "))
b = int(input("請輸入高: "))

for i in range(a) :
    for j in range(b) :
        print('*',end='')
    print()
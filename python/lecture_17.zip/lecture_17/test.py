def add(a,b) :
    return a+b

#main
x = 2
y = 3
z = add(x,y)
print(z)
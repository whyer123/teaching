#歐幾里得演算法 輾轉相除法
#gcd(a,b)=gcd(b,a%b), while b!=0, and final ans is a
#example gcd(12,18)? 
# gcd(12,18) = gcd(18,12) = gcd(12,6) = gcd(6,0)